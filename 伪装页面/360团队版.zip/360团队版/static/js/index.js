/* eslint-disable no-undef 
var token = new URLSearchParams(location.href.split('?')[1]).get('token')

$(document).tooltip({
  position: {
    my: 'center bottom+32'
  }
})
function getInform() {
  $.get(
    '/download/getsaasinfo', { token: token }
  ).done(function(res) {
    if (res.errno === 1000001) {
      return alert('当前链接已失效，请联系管理员获取最新链接')
    }
    if (res.errno) {
      return alert('请求失败：' + res.errmsg)
    }

    var data = res.data

    $('.d-pin').text(data.pinCode)
    $('p.company-name').text(data.companyName)

    var list = data.auth
    var item = list[1]
    $('.d-btn').on('click', function() {
      window.open(item.downurl, '_blank')
    })
  }).error(function(e) {
    alert('请求失败：' + e.statusText, 'warning')
  })
}

getInform()
*/